
# DSP × ML Notebook Bundle

Research-grade notebooks explained simply.

## Included Notebooks
1. AR Modeling & Yule-Walker
2. Levinson-Durbin & Lattice Filters
3. Transformer Self-Attention
4. OFDM Communication System
5. Adaptive Filters — LMS & RLS
6. Speech Feature Extraction

## Requirements
- numpy
- scipy
- matplotlib
- torch
- librosa

Built by Biswadeep.
